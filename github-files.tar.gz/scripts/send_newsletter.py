#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import os
import json
import smtplib
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart
from datetime import datetime
from jinja2 import Template

class NewsletterSender:
    def __init__(self):
        self.email_config = {
            'smtp_server': os.getenv('SMTP_SERVER', 'smtp.gmail.com'),
            'smtp_port': int(os.getenv('SMTP_PORT', '587')),
            'sender_email': os.getenv('SENDER_EMAIL'),
            'sender_password': os.getenv('SENDER_PASSWORD'),
            'sender_name': os.getenv('SENDER_NAME', 'Seinfeld Daily')
        }
        
    def load_subscribers(self):
        """تحميل قائمة المشتركين"""
        try:
            with open('data/subscribers.json', 'r', encoding='utf-8') as f:
                subscribers = json.load(f)
                # فلترة المشتركين النشطين فقط
                return [s for s in subscribers if s.get('active', True)]
        except FileNotFoundError:
            print("⚠️ ملف المشتركين غير موجود")
            return []
    
    def load_daily_content(self):
        """تحميل المحتوى اليومي"""
        try:
            with open('data/current_content.json', 'r', encoding='utf-8') as f:
                return json.load(f)
        except FileNotFoundError:
            print("❌ ملف المحتوى اليومي غير موجود")
            return None
    
    def create_email_template(self):
        """إنشاء قالب الإيميل"""
        template_html = """
        <!DOCTYPE html>
        <html dir="rtl" lang="ar">
        <head>
            <meta charset="UTF-8">
            <meta name="viewport" content="width=device-width, initial-scale=1.0">
            <title>Seinfeld Daily - مقطع اليوم</title>
            <style>
                body {
                    font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
                    line-height: 1.6;
                    color: #333;
                    max-width: 600px;
                    margin: 0 auto;
                    padding: 20px;
                    background-color: #f5f5f5;
                }
                .container {
                    background-color: white;
                    border-radius: 10px;
                    padding: 30px;
                    box-shadow: 0 4px 6px rgba(0,0,0,0.1);
                }
                .header {
                    text-align: center;
                    border-bottom: 3px solid #4F46E5;
                    padding-bottom: 20px;
                    margin-bottom: 30px;
                }
                .logo {
                    font-size: 28px;
                    font-weight: bold;
                    color: #4F46E5;
                    margin-bottom: 10px;
                }
                .subtitle {
                    color: #666;
                    font-size: 16px;
                }
                .episode-info {
                    color: #999;
                    font-size: 14px;
                    margin-top: 10px;
                }
                .content-section {
                    margin-bottom: 25px;
                    padding: 20px;
                    background-color: #f8fafc;
                    border-radius: 8px;
                    border-right: 4px solid #4F46E5;
                }
                .section-title {
                    font-size: 18px;
                    font-weight: bold;
                    color: #4F46E5;
                    margin-bottom: 15px;
                    display: flex;
                    align-items: center;
                    gap: 10px;
                }
                .transcript {
                    background-color: #e5e7eb;
                    padding: 15px;
                    border-radius: 6px;
                    font-family: monospace;
                    font-size: 16px;
                    line-height: 1.5;
                    margin-bottom: 15px;
                    text-align: left;
                    direction: ltr;
                }
                .translation {
                    background-color: #dbeafe;
                    padding: 15px;
                    border-radius: 6px;
                    font-size: 16px;
                    line-height: 1.6;
                    margin-bottom: 10px;
                }
                .translation-notes {
                    background-color: #fef3c7;
                    padding: 12px;
                    border-radius: 6px;
                    font-size: 14px;
                    border-right: 3px solid #f59e0b;
                }
                .analysis-item {
                    background-color: white;
                    padding: 15px;
                    border-radius: 6px;
                    margin-bottom: 15px;
                    border: 1px solid #e5e7eb;
                }
                .word {
                    font-weight: bold;
                    color: #4F46E5;
                    font-size: 18px;
                    margin-bottom: 8px;
                    font-family: monospace;
                }
                .word-type {
                    background-color: #e0e7ff;
                    color: #3730a3;
                    padding: 4px 8px;
                    border-radius: 4px;
                    font-size: 12px;
                    font-weight: bold;
                    margin-bottom: 10px;
                    display: inline-block;
                }
                .pronunciation {
                    background-color: #fef3c7;
                    padding: 8px 12px;
                    border-radius: 4px;
                    font-family: monospace;
                    font-size: 14px;
                    margin: 8px 0;
                    display: block;
                }
                .jerry-pronunciation {
                    background-color: #fecaca;
                    color: #991b1b;
                    font-weight: bold;
                }
                .cta-button {
                    display: inline-block;
                    background-color: #4F46E5;
                    color: white;
                    padding: 15px 30px;
                    text-decoration: none;
                    border-radius: 8px;
                    font-weight: bold;
                    margin: 20px 0;
                    text-align: center;
                    font-size: 16px;
                }
                .footer {
                    text-align: center;
                    margin-top: 30px;
                    padding-top: 20px;
                    border-top: 1px solid #e5e7eb;
                    color: #666;
                    font-size: 14px;
                }
                .unsubscribe {
                    color: #999;
                    font-size: 12px;
                    margin-top: 15px;
                }
                .audio-note {
                    background-color: #ecfdf5;
                    border: 1px solid #10b981;
                    border-radius: 6px;
                    padding: 12px;
                    margin: 15px 0;
                    text-align: center;
                }
            </style>
        </head>
        <body>
            <div class="container">
                <div class="header">
                    <div class="logo">🎭 Seinfeld Daily</div>
                    <div class="subtitle">تعلم الإنجليزية مع ساينفلد - مقطع اليوم</div>
                    <div class="episode-info">
                        {{ content.date }} | {{ content.episode.description }}: {{ content.episode.title }}
                    </div>
                </div>

                <div class="content-section">
                    <div class="section-title">
                        <span>🎬</span>
                        <span>{{ content.clip.title }}</span>
                    </div>
                    
                    <div class="audio-note">
                        🎤 <strong>صوت حقيقي من المسلسل متاح على الموقع</strong>
                    </div>
                    
                    <div class="transcript">{{ content.clip.transcript }}</div>
                    
                    <div class="translation">
                        <strong>الترجمة الحرفية:</strong><br>
                        {{ content.translation.literal }}
                    </div>
                    
                    <div class="translation">
                        <strong>الترجمة بالمعنى:</strong><br>
                        {{ content.translation.contextual }}
                    </div>
                    
                    {% if content.translation.notes %}
                    <div class="translation-notes">
                        <strong>💡 ملاحظات:</strong><br>
                        {{ content.translation.notes }}
                    </div>
                    {% endif %}
                </div>

                <div class="content-section">
                    <div class="section-title">
                        <span>📚</span>
                        <span>التحليل اللغوي مع النطق بأسلوب جيري</span>
                    </div>
                    
                    {% for item in content.analysis %}
                    <div class="analysis-item">
                        <div class="word">{{ item.word }}</div>
                        <div class="word-type">{{ item.type }}</div>
                        <p>{{ item.explanation }}</p>
                        
                        {% if item.pronunciation %}
                        <div class="pronunciation">
                            <strong>النطق العادي:</strong> {{ item.pronunciation }}
                        </div>
                        {% endif %}
                        
                        {% if item.jerry_pronunciation %}
                        <div class="pronunciation jerry-pronunciation">
                            <strong>🎭 نطق جيري:</strong> {{ item.jerry_pronunciation }}
                        </div>
                        {% endif %}
                    </div>
                    {% endfor %}
                </div>

                <div style="text-align: center;">
                    <a href="{{ content.website_url }}" class="cta-button">
                        🌐 زيارة الموقع للاستماع والمزيد
                    </a>
                </div>

                <div class="footer">
                    <p><strong>شكراً لاشتراكك في Seinfeld Daily!</strong></p>
                    <p>نرسل لك مقطعاً جديداً كل يوم في تمام الساعة 1:00 ظهراً</p>
                    <p>🎯 تعلم الإنجليزية بطريقة ممتعة مع أشهر مسلسل كوميدي أمريكي</p>
                    
                    <div class="unsubscribe">
                        <p>لإلغاء الاشتراك، أرسل إيميل إلى unsubscribe@seinfeld-daily.com</p>
                        <p>أو قم بزيارة الموقع وإلغاء الاشتراك من هناك</p>
                    </div>
                </div>
            </div>
        </body>
        </html>
        """
        return Template(template_html)
    
    def send_email(self, subscriber_email, content):
        """إرسال إيميل لمشترك واحد"""
        try:
            # إنشاء رسالة الإيميل
            msg = MIMEMultipart('alternative')
            msg['From'] = f"{self.email_config['sender_name']} <{self.email_config['sender_email']}>"
            msg['To'] = subscriber_email
            msg['Subject'] = f"🎭 Seinfeld Daily - مقطع اليوم ({content['date']})"

            # إنشاء محتوى HTML
            template = self.create_email_template()
            html_content = template.render(content=content)
            
            # إضافة المحتوى للرسالة
            html_part = MIMEText(html_content, 'html', 'utf-8')
            msg.attach(html_part)

            # إرسال الإيميل
            server = smtplib.SMTP(self.email_config['smtp_server'], self.email_config['smtp_port'])
            server.starttls()
            server.login(self.email_config['sender_email'], self.email_config['sender_password'])
            
            text = msg.as_string()
            server.sendmail(self.email_config['sender_email'], subscriber_email, text)
            server.quit()
            
            print(f"✅ تم إرسال الإيميل بنجاح إلى: {subscriber_email}")
            return True
            
        except Exception as e:
            print(f"❌ خطأ في إرسال الإيميل إلى {subscriber_email}: {str(e)}")
            return False
    
    def send_newsletter(self):
        """إرسال النشرة اليومية لجميع المشتركين"""
        print("📧 بدء إرسال النشرة اليومية...")
        
        # التحقق من إعدادات الإيميل
        if not all([self.email_config['sender_email'], self.email_config['sender_password']]):
            print("❌ إعدادات الإيميل غير مكتملة")
            return False
        
        subscribers = self.load_subscribers()
        content = self.load_daily_content()
        
        if not content:
            print("❌ لا يوجد محتوى يومي")
            return False
        
        if not subscribers:
            print("⚠️ لا يوجد مشتركين")
            return True
        
        print(f"📋 عدد المشتركين: {len(subscribers)}")
        print(f"📅 تاريخ المحتوى: {content['date']}")
        print(f"🎬 الحلقة: {content['episode']['title']}")
        
        success_count = 0
        for subscriber in subscribers:
            if self.send_email(subscriber['email'], content):
                success_count += 1
            # تأخير بسيط بين الإرسالات لتجنب الحظر
            import time
            time.sleep(2)
        
        print(f"✅ تم إرسال النشرة اليومية إلى {success_count} من {len(subscribers)} مشترك")
        
        # حفظ إحصائيات الإرسال
        stats = {
            "date": content['date'],
            "total_subscribers": len(subscribers),
            "successful_sends": success_count,
            "timestamp": datetime.now().isoformat()
        }
        
        os.makedirs("data/stats", exist_ok=True)
        with open(f"data/stats/newsletter_{content['date']}.json", 'w', encoding='utf-8') as f:
            json.dump(stats, f, ensure_ascii=False, indent=2)
        
        return success_count > 0

def main():
    """الدالة الرئيسية"""
    print("🎭 بدء خدمة إرسال النشرة اليومية لـ Seinfeld Daily...")
    
    sender = NewsletterSender()
    success = sender.send_newsletter()
    
    if success:
        print("🎉 تم إرسال النشرة اليومية بنجاح!")
    else:
        print("❌ فشل في إرسال النشرة اليومية")
        exit(1)

if __name__ == "__main__":
    main()

