#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import os
import json
import random
from datetime import datetime, timedelta
import requests
from bs4 import BeautifulSoup
import re

class SeinfeldContentGenerator:
    def __init__(self):
        self.episodes_data = self.load_episodes_data()
        self.audio_sources = self.load_audio_sources()
        
    def load_episodes_data(self):
        """تحميل بيانات الحلقات"""
        episodes = [
            {
                "season": 1, "episode": 1, "title": "The Seinfeld Chronicles",
                "clips": [
                    {
                        "transcript": "What's the deal with airplane peanuts?",
                        "context": "Jerry's standup routine about airline food"
                    }
                ]
            },
            {
                "season": 4, "episode": 11, "title": "The Contest",
                "clips": [
                    {
                        "transcript": "I'm out!",
                        "context": "George declares he's out of the contest"
                    },
                    {
                        "transcript": "Are you master of your domain?",
                        "context": "Jerry asks about self-control"
                    }
                ]
            },
            {
                "season": 5, "episode": 6, "title": "The Lip Reader",
                "clips": [
                    {
                        "transcript": "These pretzels are making me thirsty!",
                        "context": "Kramer practicing his line"
                    }
                ]
            },
            {
                "season": 7, "episode": 1, "title": "The Engagement",
                "clips": [
                    {
                        "transcript": "I don't want to be a pirate!",
                        "context": "Jerry complaining about the puffy shirt"
                    }
                ]
            },
            {
                "season": 8, "episode": 21, "title": "The Muffin Tops",
                "clips": [
                    {
                        "transcript": "Top of the muffin to you!",
                        "context": "Elaine's muffin top business idea"
                    }
                ]
            }
        ]
        return episodes
        
    def load_audio_sources(self):
        """تحميل مصادر الملفات الصوتية"""
        return {
            "jerry_all_right": "/audio/jerry_all_right.wav",
            "george_im_out": "/audio/george_im_out.wav",
            "kramer_pretzels": "/audio/kramer_pretzels.wav",
            "elaine_get_out": "/audio/elaine_get_out.wav"
        }
    
    def analyze_text(self, text):
        """تحليل النص لغوياً"""
        words = text.lower().split()
        analysis = []
        
        # قاموس التحليل اللغوي
        word_analysis = {
            "what's": {
                "type": "contraction",
                "explanation": "اختصار لـ 'what is'. شائع في الإنجليزية المحكية.",
                "pronunciation": "/wʌts/",
                "jerry_pronunciation": "WUTZ (سريع ومدمج)"
            },
            "deal": {
                "type": "idiom",
                "explanation": "في 'What's the deal' تعني 'ما المشكلة' أو 'ما القصة'.",
                "pronunciation": "/diːl/",
                "jerry_pronunciation": "DEEL (تشديد طويل)"
            },
            "airplane": {
                "type": "compound",
                "explanation": "كلمة مركبة من air + plane. تعني طائرة.",
                "pronunciation": "/ˈɛrpleɪn/",
                "jerry_pronunciation": "AIR-plane (تشديد على المقطع الأول)"
            },
            "peanuts": {
                "type": "cultural",
                "explanation": "الفول السوداني المقدم في الطائرات. موضوع كوميدي شائع.",
                "pronunciation": "/ˈpiːnʌts/",
                "jerry_pronunciation": "PEE-nuts (تشديد ساخر)"
            },
            "i'm": {
                "type": "contraction",
                "explanation": "اختصار لـ 'I am'. أساسي في الإنجليزية.",
                "pronunciation": "/aɪm/",
                "jerry_pronunciation": "AHM (قصير وحاسم)"
            },
            "out": {
                "type": "idiom",
                "explanation": "في سياق المسابقة تعني 'خرجت' أو 'استسلمت'.",
                "pronunciation": "/aʊt/",
                "jerry_pronunciation": "OWWWT (إطالة درامية)"
            },
            "master": {
                "type": "idiom",
                "explanation": "في 'master of your domain' تعني السيطرة على النفس.",
                "pronunciation": "/ˈmæstər/",
                "jerry_pronunciation": "MAS-ter (تشديد استفهامي)"
            },
            "domain": {
                "type": "metaphor",
                "explanation": "استعارة للسيطرة على النفس والرغبات.",
                "pronunciation": "/doʊˈmeɪn/",
                "jerry_pronunciation": "do-MAIN (تشديد على المقطع الثاني)"
            },
            "pretzels": {
                "type": "cultural",
                "explanation": "نوع من المعجنات المملحة. طعام أمريكي شائع.",
                "pronunciation": "/ˈprɛtsəlz/",
                "jerry_pronunciation": "PRET-zels (تشديد غاضب)"
            },
            "thirsty": {
                "type": "adjective",
                "explanation": "عطشان. كرامر يشكو من ملوحة البريتزل.",
                "pronunciation": "/ˈθɜrsti/",
                "jerry_pronunciation": "THURS-tee (تشديد على المقطع الأول)"
            },
            "pirate": {
                "type": "cultural",
                "explanation": "قرصان. جيري يشكو من قميص منفوش يجعله يبدو كقرصان.",
                "pronunciation": "/ˈpaɪrət/",
                "jerry_pronunciation": "PIE-rate (تشديد محتج)"
            },
            "muffin": {
                "type": "cultural",
                "explanation": "نوع من الكعك. إيلين تريد بيع قمم المافن فقط.",
                "pronunciation": "/ˈmʌfɪn/",
                "jerry_pronunciation": "MUF-fin (تشديد متحمس)"
            }
        }
        
        for word in words:
            clean_word = re.sub(r'[^\w]', '', word)
            if clean_word in word_analysis:
                analysis.append({
                    "word": word,
                    **word_analysis[clean_word]
                })
        
        return analysis
    
    def translate_text(self, text):
        """ترجمة النص حرفياً وسياقياً"""
        translations = {
            "What's the deal with airplane peanuts?": {
                "literal": "ما هي الصفقة مع فول سوداني الطائرة؟",
                "contextual": "ما المشكلة مع الفول السوداني في الطائرات؟",
                "notes": "عبارة شهيرة لجيري ساينفلد يسخر فيها من الطعام المقدم في الطائرات"
            },
            "I'm out!": {
                "literal": "أنا خارج!",
                "contextual": "استسلمت! / خرجت من المسابقة!",
                "notes": "جورج يعلن خروجه من مسابقة ضبط النفس الشهيرة"
            },
            "Are you master of your domain?": {
                "literal": "هل أنت سيد مجالك؟",
                "contextual": "هل تسيطر على نفسك؟ / هل تتحكم في رغباتك؟",
                "notes": "سؤال فلسفي ساخر حول ضبط النفس والسيطرة على الرغبات"
            },
            "These pretzels are making me thirsty!": {
                "literal": "هذه البريتزل تجعلني عطشان!",
                "contextual": "هذا البريتزل المملح يعطشني!",
                "notes": "كرامر يتدرب على جملة لدور تمثيلي، لكنه يقولها بطريقة مضحكة"
            },
            "I don't want to be a pirate!": {
                "literal": "لا أريد أن أكون قرصان!",
                "contextual": "لا أريد أن أبدو كقرصان!",
                "notes": "جيري يشكو من قميص منفوش يجعله يبدو كقرصان من القرن الثامن عشر"
            },
            "Top of the muffin to you!": {
                "literal": "قمة المافن لك!",
                "contextual": "أفضل جزء من المافن لك!",
                "notes": "إيلين تحية مبتكرة لعملها في بيع قمم المافن فقط"
            }
        }
        
        return translations.get(text, {
            "literal": text,
            "contextual": text,
            "notes": "ترجمة تلقائية"
        })
    
    def generate_daily_content(self):
        """توليد محتوى يومي جديد"""
        today = datetime.now()
        
        # اختيار حلقة عشوائية
        episode = random.choice(self.episodes_data)
        clip_data = random.choice(episode["clips"])
        
        # تحليل النص
        analysis = self.analyze_text(clip_data["transcript"])
        translation = self.translate_text(clip_data["transcript"])
        
        # اختيار ملف صوتي
        audio_file = random.choice(list(self.audio_sources.values()))
        
        content = {
            "date": today.strftime("%Y-%m-%d"),
            "episode": {
                "title": episode["title"],
                "season": episode["season"],
                "episode": episode["episode"],
                "description": f"الموسم {episode['season']} - الحلقة {episode['episode']}"
            },
            "clip": {
                "title": f"مقطع من {episode['title']}",
                "transcript": clip_data["transcript"],
                "context": clip_data["context"],
                "audio_file": audio_file,
                "difficulty_level": random.randint(1, 3)
            },
            "translation": translation,
            "analysis": analysis,
            "website_url": "https://cnbzzidh.manus.space"
        }
        
        return content
    
    def save_daily_content(self, content):
        """حفظ المحتوى اليومي"""
        filename = f"data/daily_content_{content['date']}.json"
        os.makedirs("data", exist_ok=True)
        
        with open(filename, 'w', encoding='utf-8') as f:
            json.dump(content, f, ensure_ascii=False, indent=2)
        
        # حفظ كملف حالي أيضاً
        with open("data/current_content.json", 'w', encoding='utf-8') as f:
            json.dump(content, f, ensure_ascii=False, indent=2)
        
        print(f"تم حفظ المحتوى اليومي: {filename}")
        return filename

def main():
    """الدالة الرئيسية"""
    print("🎭 بدء توليد المحتوى اليومي لـ Seinfeld Daily...")
    
    generator = SeinfeldContentGenerator()
    content = generator.generate_daily_content()
    filename = generator.save_daily_content(content)
    
    print(f"✅ تم توليد المحتوى بنجاح:")
    print(f"   📅 التاريخ: {content['date']}")
    print(f"   🎬 الحلقة: {content['episode']['title']}")
    print(f"   📝 النص: {content['clip']['transcript']}")
    print(f"   💾 الملف: {filename}")

if __name__ == "__main__":
    main()

