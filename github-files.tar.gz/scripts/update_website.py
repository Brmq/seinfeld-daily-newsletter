#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import os
import json
import shutil
from datetime import datetime

def update_website():
    """تحديث الموقع بالمحتوى الجديد"""
    print("🌐 بدء تحديث الموقع...")
    
    # تحميل المحتوى الجديد
    try:
        with open('data/current_content.json', 'r', encoding='utf-8') as f:
            content = json.load(f)
    except FileNotFoundError:
        print("❌ ملف المحتوى غير موجود")
        return False
    
    # تحديث ملف البيانات في الموقع
    website_data = {
        "lastUpdated": datetime.now().isoformat(),
        "dailyClip": {
            "id": 1,
            "date": content["date"],
            "episode": content["episode"],
            "clip": content["clip"],
            "translation": content["translation"],
            "analysis": content["analysis"]
        }
    }
    
    # حفظ البيانات المحدثة
    os.makedirs("website/data", exist_ok=True)
    with open("website/data/daily_content.json", 'w', encoding='utf-8') as f:
        json.dump(website_data, f, ensure_ascii=False, indent=2)
    
    # نسخ الملفات الصوتية إذا كانت موجودة
    audio_dir = "website/public/audio"
    os.makedirs(audio_dir, exist_ok=True)
    
    # نسخ ملفات الصوت من مجلد الأصول
    if os.path.exists("assets/audio"):
        for audio_file in os.listdir("assets/audio"):
            if audio_file.endswith(('.wav', '.mp3', '.ogg')):
                src = os.path.join("assets/audio", audio_file)
                dst = os.path.join(audio_dir, audio_file)
                shutil.copy2(src, dst)
                print(f"📁 تم نسخ الملف الصوتي: {audio_file}")
    
    # إنشاء ملف README محدث
    readme_content = f"""# Seinfeld Daily - تعلم الإنجليزية مع ساينفلد

## آخر تحديث: {content['date']}

### مقطع اليوم
**الحلقة:** {content['episode']['title']} (الموسم {content['episode']['season']} - الحلقة {content['episode']['episode']})

**النص:** {content['clip']['transcript']}

**الترجمة:** {content['translation']['contextual']}

---

## 🎯 المشروع

مشروع تعليمي يهدف لتعلم الإنجليزية من خلال مقاطع من مسلسل ساينفلد الشهير.

### الميزات:
- 🎬 مقاطع يومية من المسلسل
- 🔤 ترجمة حرفية وسياقية
- 📚 تحليل لغوي شامل
- 🎭 النطق بأسلوب جيري ساينفلد
- 🎤 ملفات صوتية حقيقية من المسلسل
- 📧 نشرة يومية عبر الإيميل

### التقنيات المستخدمة:
- React.js للواجهة الأمامية
- GitHub Actions للجدولة التلقائية
- Python لمعالجة البيانات وإرسال الإيميلات
- HTML/CSS للتصميم المتجاوب

### الاستخدام:
1. زيارة الموقع يومياً للحصول على مقطع جديد
2. الاشتراك في النشرة اليومية عبر الإيميل
3. الاستماع للملفات الصوتية الحقيقية
4. دراسة التحليل اللغوي والنطق

---

## 📊 الإحصائيات

- **تاريخ البدء:** 2025-06-18
- **عدد الحلقات المتاحة:** 180+ حلقة
- **عدد المقاطع:** 500+ مقطع
- **اللغات:** الإنجليزية والعربية

---

## 🤝 المساهمة

هذا مشروع مفتوح المصدر. يمكنك المساهمة بـ:
- إضافة مقاطع جديدة
- تحسين الترجمات
- إضافة ملفات صوتية
- تطوير الواجهة

---

## 📧 التواصل

للاستفسارات والاقتراحات: seinfeld.daily@gmail.com

---

*"What's the deal with learning English? Now you can do it with Seinfeld!"* 🎭
"""
    
    with open("README.md", 'w', encoding='utf-8') as f:
        f.write(readme_content)
    
    print(f"✅ تم تحديث الموقع بنجاح - {content['date']}")
    print(f"🎬 الحلقة: {content['episode']['title']}")
    print(f"📝 النص: {content['clip']['transcript']}")
    
    return True

def main():
    """الدالة الرئيسية"""
    print("🌐 بدء تحديث موقع Seinfeld Daily...")
    
    success = update_website()
    
    if success:
        print("🎉 تم تحديث الموقع بنجاح!")
    else:
        print("❌ فشل في تحديث الموقع")
        exit(1)

if __name__ == "__main__":
    main()

