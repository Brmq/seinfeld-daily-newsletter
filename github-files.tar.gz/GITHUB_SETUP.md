# Seinfeld Daily - GitHub Actions Setup

## 🎯 نظام الجدولة التلقائي

هذا المشروع يستخدم GitHub Actions لإرسال نشرة يومية تلقائياً في تمام الساعة 1:00 ظهراً.

## 📋 خطوات الإعداد

### 1. إنشاء مستودع GitHub جديد

```bash
# إنشاء مستودع جديد على GitHub
# اسم المستودع: seinfeld-daily-newsletter
```

### 2. إعداد المفاتيح السرية (Secrets)

في إعدادات المستودع، أضف المفاتيح التالية في `Settings > Secrets and variables > Actions`:

#### إعدادات الإيميل:
- `SMTP_SERVER`: خادم SMTP (مثل: smtp.gmail.com)
- `SMTP_PORT`: منفذ SMTP (مثل: 587)
- `SENDER_EMAIL`: الإيميل المرسل
- `SENDER_PASSWORD`: كلمة مرور التطبيق (App Password)
- `SENDER_NAME`: اسم المرسل (مثل: Seinfeld Daily)

#### للحصول على كلمة مرور التطبيق من Gmail:
1. اذهب إلى [Google Account Settings](https://myaccount.google.com/)
2. Security > 2-Step Verification
3. App passwords > Generate new password
4. اختر "Mail" و "Other" واكتب "Seinfeld Daily"
5. انسخ كلمة المرور المولدة واستخدمها في `SENDER_PASSWORD`

### 3. رفع الملفات للمستودع

```bash
# استنساخ المستودع
git clone https://github.com/YOUR_USERNAME/seinfeld-daily-newsletter.git
cd seinfeld-daily-newsletter

# نسخ جميع الملفات من هذا المجلد
cp -r /home/ubuntu/seinfeld-github-project/* .

# إضافة الملفات
git add .
git commit -m "Initial setup: Seinfeld Daily Newsletter with GitHub Actions"
git push origin main
```

### 4. إنشاء ملف المشتركين

أنشئ ملف `data/subscribers.json` بالتنسيق التالي:

```json
[
  {
    "email": "your-email@example.com",
    "name": "اسمك",
    "subscribed_at": "2025-06-18T10:00:00",
    "active": true
  }
]
```

### 5. تفعيل GitHub Actions

1. اذهب إلى تبويب "Actions" في المستودع
2. فعّل GitHub Actions إذا لم تكن مفعلة
3. ستجد workflow باسم "Seinfeld Daily Newsletter"
4. يمكنك تشغيله يدوياً من "Run workflow"

## 🕐 جدولة التشغيل

- **التوقيت**: يومياً في تمام الساعة 1:00 ظهراً (بتوقيت الرياض)
- **التوقيت في GitHub**: 10:00 صباحاً UTC
- **التكرار**: يومياً بدون انقطاع

## 📧 كيفية عمل النظام

1. **توليد المحتوى**: يختار مقطعاً عشوائياً من ساينفلد
2. **التحليل اللغوي**: يحلل النص ويضيف النطق بأسلوب جيري
3. **إنشاء الإيميل**: ينشئ إيميل HTML جميل ومنسق
4. **الإرسال**: يرسل لجميع المشتركين النشطين
5. **التحديث**: يحدث الموقع بالمحتوى الجديد

## 🔧 التخصيص

### إضافة مقاطع جديدة:
عدّل ملف `scripts/generate_daily_content.py` وأضف حلقات ومقاطع جديدة.

### تغيير التوقيت:
عدّل ملف `.github/workflows/daily-newsletter.yml` وغيّر قيمة `cron`.

### تخصيص الإيميل:
عدّل قالب HTML في `scripts/send_newsletter.py`.

## 📊 المراقبة

- **السجلات**: تحقق من تبويب "Actions" لرؤية سجلات التشغيل
- **الإحصائيات**: تُحفظ في مجلد `data/stats/`
- **الأخطاء**: تظهر في سجلات GitHub Actions

## 🚨 استكشاف الأخطاء

### إذا لم يتم الإرسال:
1. تحقق من المفاتيح السرية
2. تأكد من صحة كلمة مرور التطبيق
3. راجع سجلات GitHub Actions

### إذا كان الإيميل في الـ Spam:
1. أضف الإيميل المرسل للقائمة البيضاء
2. استخدم إيميل مخصص بدلاً من Gmail
3. أضف SPF و DKIM records

## 🎉 الاستخدام

بعد الإعداد، سيعمل النظام تلقائياً:
- ✅ توليد محتوى يومي جديد
- ✅ إرسال نشرة عبر الإيميل
- ✅ تحديث الموقع
- ✅ حفظ الإحصائيات

---

**ملاحظة**: تأكد من أن المستودع عام (Public) أو لديك GitHub Pro لاستخدام GitHub Actions مع المستودعات الخاصة.

